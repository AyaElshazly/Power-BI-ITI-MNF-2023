SELECT Course.Crs_Name, Student.St_Fname+'  '+  Student.St_Lname AS [Student Name], Stud_Course.Grade
FROM     Course INNER JOIN
                  Stud_Course ON Course.Crs_Id = Stud_Course.Crs_Id INNER JOIN
                  Student ON Stud_Course.St_Id = Student.St_Id

	  
create table sales
(
ProductID int,
SalesmanName varchar(10),
Quantity int
)
Go

insert into sales
values  (1,'ahmed',10),
		(1,'khalid',20),
		(1,'ali',45),
		(2,'ahmed',15),
		(2,'khalid',30),
		(2,'ali',20),
		(3,'ahmed',30),
		(4,'ali',80),
		(1,'ahmed',25),
		(1,'khalid',10),
		(1,'ali',100),
		(2,'ahmed',55),
		(2,'khalid',40),
		(2,'ali',70),
		(3,'ahmed',30),
		(4,'ali',90),
		(3,'khalid',30),
		(4,'khalid',90)
		
	--6)	Create report that display all courses data using Stored Procedure
create proc getcourse
as
select * from Course
--7 all student data using Stored Procedure that takes 2 parameters [Age1 and age2] and then Display parameters in the header by using Expressions
create proc GetStudByAge @Age1 int, @Age2 int
as
select * from Student
where St_Age between @Age1 and @Age2